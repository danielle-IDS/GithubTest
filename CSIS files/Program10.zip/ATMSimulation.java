
/**
   A simulation of an automatic teller machine
*/

public class ATMSimulation
{  
	public static void main(String[] args)
	{  
		ATM frame = new ATM();
		frame.setTitle("First National Bank of GFU");      
	}
}

